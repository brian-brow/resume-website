import { forwardRef } from "react";
import { PondWindow } from "../pond/react";
import { ArrowLeft } from "./icons";
import { useClock } from "./useClock";

interface InsideProps {
  open: boolean;
  pondActive: boolean;
  onLeave: () => void;
}

const links = [
  { label: "GitHub", detail: "@[HANDLE]", href: "#" },
  { label: "X / Twitter", detail: "@[HANDLE]", href: "#" },
  { label: "LinkedIn", detail: "[NAME]", href: "#" },
  { label: "Email", detail: "[YOU@DOMAIN]", href: "#" },
];

const projects = [
  { title: "[Game or project name]", status: "[In progress]", href: "#" },
  { title: "[Another thing you made]", status: "[Year]", href: "#" },
];

const posts = [
  { date: "[DATE]", title: "[Most recent post title]", href: "#" },
  { date: "[DATE]", title: "[Older post title]", href: "#" },
  { date: "[DATE]", title: "[Oldest post title]", href: "#" },
];

/** The four rooms behind the door. */
export const Inside = forwardRef<HTMLButtonElement, InsideProps>(function Inside({ open, pondActive, onLeave }, backRef) {
  const time = useClock();
  return (
    <div className="layer layer-inside" data-pond-layer inert={!open}>
      <header className="bar">
        <div className="bar-mark">BB</div>
        <button ref={backRef} type="button" className="bar-action" onClick={onLeave}>
          <ArrowLeft />
          <span>Back to index</span>
        </button>
        <div className="bar-meta">
          <span>Index / Inside</span>
          <span>{time} · [Your city]</span>
        </div>
      </header>

      <main className="grid">
        <section className="cell room room-bio" aria-labelledby="bio-h">
          <h2 id="bio-h" className="label">01 — Bio</h2>
          <p className="bio">[Two or three sentences about you: what you do, what you are into lately, and what you care about.]</p>
          <div className="room-foot label">
            <span>Based in [Your city]</span>
            <span>[Your role / school / current thing]</span>
          </div>
        </section>

        <section className="cell room room-links" aria-labelledby="links-h">
          <h2 id="links-h" className="label">02 — Links</h2>
          <nav className="rows">
            {links.map((l) => (
              <a key={l.label} className="row row-link" href={l.href}>
                <span>{l.label}</span>
                <span className="label">{l.detail} ↗</span>
              </a>
            ))}
          </nav>
        </section>

        <PondWindow className="cell room room-play" active={pondActive}>
          <h2 className="label chip">03 — Play</h2>
          <div className="cards">
            {projects.map((p) => (
              <a key={p.title} className="card" href={p.href}>
                <span>{p.title}</span>
                <span className="label">{p.status} ↗</span>
              </a>
            ))}
          </div>
        </PondWindow>

        <section className="cell room room-writing" aria-labelledby="writing-h">
          <h2 id="writing-h" className="label">04 — Writing</h2>
          <div className="rows rows-ink">
            {posts.map((p, i) => (
              <a key={i} className="row row-post" href={p.href}>
                <span className="label post-date">{p.date}</span>
                <span>{p.title}</span>
              </a>
            ))}
          </div>
          <a className="label" href="#">All posts →</a>
        </section>
      </main>

      {/* Solid accent at the start of the zoom so the menu reads as the door growing */}
      <div className="inside-cover" aria-hidden="true" />
    </div>
  );
});
