import { createContext, useContext, useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { Pond, type PondCore } from "./engine";
import { DOT, PondLoop } from "./loop";

const PondContext = createContext<PondLoop | null>(null);

/**
 * Creates one pond for the page and sizes its field to `stage`, the element
 * every window is positioned against (the full-screen layers).
 */
export function PondProvider({ children, core }: { children: ReactNode; core?: () => PondCore }) {
  const [loop] = useState(() => new PondLoop(core ? core() : new Pond(480, 300)));
  useEffect(() => {
    loop.start();
    return () => loop.stop();
  }, [loop]);
  return <PondContext.Provider value={loop}>{children}</PondContext.Provider>;
}

/** Attach to the stage element so the field matches its size. */
export function usePondStage<T extends HTMLElement>() {
  const loop = usePondLoop();
  const ref = useRef<T>(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(() => loop.resizeField(el.clientWidth, el.clientHeight));
    ro.observe(el);
    return () => ro.disconnect();
  }, [loop]);
  return ref;
}

function usePondLoop(): PondLoop {
  const loop = useContext(PondContext);
  if (!loop) throw new Error("Pond components must be inside <PondProvider>.");
  return loop;
}

/** Offset of `el` from its nearest ancestor marked data-pond-layer. Unaffected by CSS transforms. */
function offsetInLayer(el: HTMLElement): { left: number; top: number } {
  let left = 0;
  let top = 0;
  let node: HTMLElement | null = el;
  while (node && !node.hasAttribute("data-pond-layer")) {
    left += node.offsetLeft;
    top += node.offsetTop;
    node = node.offsetParent as HTMLElement | null;
  }
  return { left, top };
}

interface PondWindowProps {
  /** Pause painting while this window is hidden. */
  active?: boolean;
  className?: string;
  children?: ReactNode;
}

/** A cell that shows its part of the shared pond. Children render on top. */
export function PondWindow({ active = true, className, children }: PondWindowProps) {
  const loop = usePondLoop();
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const handleRef = useRef<ReturnType<PondLoop["add"]> | null>(null);

  useLayoutEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    const handle = loop.add(canvas);
    handleRef.current = handle;
    const measure = () => {
      const { left, top } = offsetInLayer(wrap);
      loop.setCrop(handle, {
        sx: Math.round(left / DOT),
        sy: Math.round(top / DOT),
        sw: Math.max(1, Math.ceil(wrap.clientWidth / DOT)),
        sh: Math.max(1, Math.ceil(wrap.clientHeight / DOT)),
      });
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(wrap);
    window.addEventListener("resize", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
      loop.remove(handle);
      handleRef.current = null;
    };
  }, [loop]);

  useEffect(() => {
    if (handleRef.current) loop.setActive(handleRef.current, active);
  }, [loop, active]);

  return (
    <div
      ref={wrapRef}
      className={["pond-window", className].filter(Boolean).join(" ")}
      onPointerMove={(e) => handleRef.current && loop.poke(handleRef.current, e.clientX, e.clientY)}
    >
      <canvas ref={canvasRef} className="pond-canvas" aria-hidden="true" />
      {children}
    </div>
  );
}
