import { useEffect, useRef, useState } from "react";
import { Home } from "./components/Home";
import { Inside } from "./components/Inside";
import { usePondStage } from "./pond/react";

const ZOOM_MS = 900;

export default function App() {
  const [open, setOpen] = useState(false);
  const [moving, setMoving] = useState(false);
  const stageRef = usePondStage<HTMLDivElement>();
  const doorRef = useRef<HTMLButtonElement>(null);
  const backRef = useRef<HTMLButtonElement>(null);
  const firstRender = useRef(true);

  // While the zoom runs both layers are visible, so both keep painting
  useEffect(() => {
    setMoving(true);
    const id = setTimeout(() => setMoving(false), ZOOM_MS);
    if (!firstRender.current) (open ? backRef : doorRef).current?.focus({ preventScroll: true });
    firstRender.current = false;
    return () => clearTimeout(id);
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div ref={stageRef} className={open ? "stage is-open" : "stage"}>
      <Home ref={doorRef} open={open} pondActive={!open || moving} onEnter={() => setOpen(true)} />
      <Inside ref={backRef} open={open} pondActive={open || moving} onLeave={() => setOpen(false)} />
    </div>
  );
}
